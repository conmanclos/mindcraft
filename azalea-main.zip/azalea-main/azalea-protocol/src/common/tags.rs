use std::{
    io::{self, Cursor, Write},
    ops::Deref,
};

use azalea_buf::{AzBuf, AzBufVar, BufReadError};
use azalea_registry::identifier::Identifier;
use indexmap::IndexMap;

#[derive(Clone, Debug, PartialEq)]
pub struct TagMap(pub IndexMap<Identifier, Vec<Tags>>);

#[derive(Clone, Debug, PartialEq)]
pub struct Tags {
    pub name: Identifier,
    pub elements: Vec<i32>,
}

impl AzBuf for TagMap {
    fn azalea_read(buf: &mut Cursor<&[u8]>) -> Result<Self, BufReadError> {
        let length = u32::azalea_read_var(buf)? as usize;
        let mut data = IndexMap::new();
        for _ in 0..length {
            let tag_type = Identifier::azalea_read(buf)?;
            let tags_count = i32::azalea_read_var(buf)? as usize;
            let mut tags_vec = Vec::new();
            for _ in 0..tags_count {
                let tags = Tags::azalea_read(buf)?;
                tags_vec.push(tags);
            }
            data.insert(tag_type, tags_vec);
        }
        Ok(TagMap(data))
    }
    fn azalea_write(&self, buf: &mut impl Write) -> io::Result<()> {
        (self.len() as u32).azalea_write_var(buf)?;
        for (k, v) in &self.0 {
            k.azalea_write(buf)?;
            v.azalea_write(buf)?;
        }
        Ok(())
    }
}
impl AzBuf for Tags {
    fn azalea_read(buf: &mut Cursor<&[u8]>) -> Result<Self, BufReadError> {
        let name = Identifier::azalea_read(buf)?;
        let elements = Vec::<i32>::azalea_read_var(buf)?;
        Ok(Tags { name, elements })
    }
    fn azalea_write(&self, buf: &mut impl Write) -> io::Result<()> {
        self.name.azalea_write(buf)?;
        self.elements.azalea_write_var(buf)?;
        Ok(())
    }
}

impl Deref for TagMap {
    type Target = IndexMap<Identifier, Vec<Tags>>;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

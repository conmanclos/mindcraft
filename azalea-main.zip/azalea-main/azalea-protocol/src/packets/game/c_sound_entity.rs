use azalea_buf::AzBuf;
use azalea_core::sound::CustomSound;
use azalea_protocol_macros::ClientboundGamePacket;
use azalea_registry::builtin::SoundEvent;
use azalea_core::entity_id::MinecraftEntityId;

use super::c_sound::SoundSource;

#[derive(AzBuf, ClientboundGamePacket, Clone, Debug, PartialEq)]
pub struct ClientboundSoundEntity {
    pub sound: azalea_registry::Holder<SoundEvent, CustomSound>,
    pub source: SoundSource,
    #[var]
    pub id: MinecraftEntityId,
    pub volume: f32,
    pub pitch: f32,
    pub seed: u64,
}

use std::io::{self, Cursor, Write};

use azalea_buf::{AzBuf, BufReadError};
use azalea_core::bitset::FixedBitSet;
use azalea_protocol_macros::ClientboundGamePacket;
use azalea_registry::identifier::Identifier;

use super::c_sound::SoundSource;

#[derive(ClientboundGamePacket, Clone, Debug, PartialEq)]
pub struct ClientboundStopSound {
    pub source: Option<SoundSource>,
    pub name: Option<Identifier>,
}

impl AzBuf for ClientboundStopSound {
    fn azalea_read(buf: &mut Cursor<&[u8]>) -> Result<Self, BufReadError> {
        let set = FixedBitSet::<2>::azalea_read(buf)?;
        let source = if set.index(0) {
            Some(SoundSource::azalea_read(buf)?)
        } else {
            None
        };
        let name = if set.index(1) {
            Some(Identifier::azalea_read(buf)?)
        } else {
            None
        };

        Ok(Self { source, name })
    }
    fn azalea_write(&self, buf: &mut impl Write) -> io::Result<()> {
        let mut set = FixedBitSet::<2>::new();
        if self.source.is_some() {
            set.set(0);
        }
        if self.name.is_some() {
            set.set(1);
        }
        set.azalea_write(buf)?;
        if let Some(source) = &self.source {
            source.azalea_write(buf)?;
        }
        if let Some(name) = &self.name {
            name.azalea_write(buf)?;
        }
        Ok(())
    }
}
